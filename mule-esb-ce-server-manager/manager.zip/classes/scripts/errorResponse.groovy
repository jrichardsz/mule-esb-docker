def response = [:];
response["status"] = 500;
return response;